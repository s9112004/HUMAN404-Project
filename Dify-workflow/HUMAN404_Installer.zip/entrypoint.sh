#!/bin/bash

echo "========================================="
echo "   🚀 HUMAN404 初始化程序啟動"
echo "========================================="

# 1. 自動安裝工具到資料庫
python setup_tool.py

echo "-----------------------------------------"
echo "💡 請現在前往 Dify 網頁介面："
echo "   1. 登入 Dify"
echo "   2. 進入 Studio"
echo "   3. 點擊 'Import DSL File'"
echo "   4. 選擇本目錄下的 'workflow.yml' 檔案"
echo "   5. 匯入後，務必點擊右上角的 'Publish' (發布)！"
echo "-----------------------------------------"
echo "   (完成後，請在此按 Enter 鍵繼續...)"
read -p ""

# 2. 啟動 CLI
echo "🚀 啟動 HUMAN404 CLI..."
python dify_cli.py
