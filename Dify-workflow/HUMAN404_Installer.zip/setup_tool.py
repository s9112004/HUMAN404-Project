import psycopg2
import json
import os
import uuid
import time

# 設定資料庫連線 (預設連線到 Dify 的 docker-db)
DB_HOST = os.getenv("DB_HOST", "db")
DB_USER = os.getenv("DB_USER", "postgres")
DB_PASSWORD = os.getenv("DB_PASSWORD", "postgres")
DB_NAME = os.getenv("DB_NAME", "dify")

# 我們 Workflow 中寫死的 Tool Provider ID (千萬不能改)
TARGET_UUID = "a3f28be8-a0df-4d09-bb14-727311d7b56d"
TOOL_NAME = "aws-lambda-manager"

def wait_for_db():
    retries = 30
    while retries > 0:
        try:
            conn = psycopg2.connect(
                host=DB_HOST, user=DB_USER, password=DB_PASSWORD, dbname=DB_NAME
            )
            conn.close()
            print("✅ 成功連線到 Dify 資料庫")
            return
        except Exception as e:
            print(f"⏳ 等待資料庫啟動中... ({str(e)})")
            time.sleep(2)
            retries -= 1
    raise Exception("無法連線到資料庫")

def install_tool():
    print("🚀 開始安裝 HUMAN404 AWS 工具...")
    
    # 讀取 Schema
    with open("openapi_schema.json", "r") as f:
        schema_data = json.load(f)
    
    conn = psycopg2.connect(
        host=DB_HOST, user=DB_USER, password=DB_PASSWORD, dbname=DB_NAME
    )
    cur = conn.cursor()

    # 1. 檢查是否已存在 (避免重複)
    cur.execute("SELECT id FROM tool_api_providers WHERE id = %s", (TARGET_UUID,))
    if cur.fetchone():
        print(f"⚠️ 工具 ID {TARGET_UUID} 已存在，正在更新 Schema...")
        cur.execute("""
            UPDATE tool_api_providers 
            SET credentials = %s, schema = %s, updated_at = NOW()
            WHERE id = %s
        """, (json.dumps({"schema_type": "openapi"}), json.dumps(schema_data), TARGET_UUID))
    else:
        print(f"✨ 正在插入新工具 {TOOL_NAME} ({TARGET_UUID})...")
        # 這裡需要一個 Tenant ID。通常我們抓第一個 Tenant (管理員)
        cur.execute("SELECT id FROM tenants LIMIT 1")
        tenant_id = cur.fetchone()[0]
        
        cur.execute("""
            INSERT INTO tool_api_providers 
            (id, tenant_id, name, label, icon, privacy_policy, custom_disclaimer, 
             credentials, schema, created_at, updated_at)
            VALUES 
            (%s, %s, %s, %s, %s, '', '', 
             %s, %s, NOW(), NOW())
        """, (
            TARGET_UUID, 
            tenant_id, 
            TOOL_NAME, 
            {"en_US": "AWS Lambda Manager", "zh_Hant": "AWS 資源管家"},
            {"content": "🚀", "background": "#E0F2FE"},
            json.dumps({"schema_type": "openapi"}),
            json.dumps(schema_data)
        ))

    conn.commit()
    cur.close()
    conn.close()
    print("✅ 工具安裝完成！")

if __name__ == "__main__":
    wait_for_db()
    install_tool()
